$(document).ready(function(){
  $('.main-nav-list img').resizeOnApproach({
    elementDefault: 50,
    elementClosest: 120,
    triggerDistance: 300
  });
});